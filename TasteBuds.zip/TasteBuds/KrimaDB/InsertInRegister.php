<?php
$con= new mysqli("localhost","root","","MyDBEmployee");
$uname=$_REQUEST["uname"];
$mno=$_REQUEST["mno"];
$mail=$_REQUEST["mail"];
$pass=$_REQUEST["pass"];
$dob=$_REQUEST["dob"];
$query="insert into register(uname,mno,mail,pass,dob) values ('$uname','$mno','$mail','$pass','$dob')";
$con->query($query);
echo "Inserted successfully..."
?>