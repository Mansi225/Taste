<?php
$cn = new mysqli("localhost","root","","TasteBuds");
$data = file_get_contents('php://input');
$dt  =  json_decode($data);
//$uid = $dt->uid;
$uname = $dt->uname;
$email = $dt->email;
$pass = $dt->pass;
/*define('UPLOAD_DIR', 'images/');
$img = $dt->img;
$img = str_replace('data:image/png;base64', ' '	, $img);
$img = str_replace(' ', '+', $img);
$data = base64_decode($img);
$file = UPLOAD_DIR.uniqid().'.png';
$success = file_put_contents($file, $data);*/
echo $query = "insert into register(uname,email,pass) values('$uname','$email','$pass')";
$cn->query($query);
echo "Successful";
?>
