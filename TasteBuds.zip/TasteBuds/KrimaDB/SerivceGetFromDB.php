<?php
$cn = new mysqli("localhost","root","","TasteBuds");
$email=$_REQUEST["email"];
$pass=$_REQUEST["pass"];
$q = mysqli_query($cn,"select * from register where email='$email' and pass='$pass'");
if (mysqli_num_rows($q)==0) 
{	
	$row = array();
    print("Failed");
	//print_r(json_encode($row));
}
else
{
	while ($row=mysqli_fetch_assoc($q))
    {
		$pp[]=$row;
	}
	echo json_encode($pp);
}
?>
