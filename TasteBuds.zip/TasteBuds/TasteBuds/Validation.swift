
import UIKit

class Validation: NSObject
{
    func isValidEmail(email:String) -> Bool
    {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let result = emailTest.evaluate(with: email)
        return result
    }
    
    func isValidUsername(user:String) -> Bool
    {
        let userRegEx = "[a-zA-Z ]+\\.?"
        let userTest = NSPredicate(format:"SELF MATCHES %@", userRegEx)
        let result = userTest.evaluate(with: user)
        return result
    }
    
    func isValidPhone(phone: String) -> Bool
    {
        let PHONE_REGEX = "^\\d{5}-\\d{3}-\\d{3}$"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", PHONE_REGEX)
        let result =  phoneTest.evaluate(with: phone)
        return result
    }
    
    func isValidMobile(mobile: String) -> Bool
    {
        //STARTING WITH +91 THEN ONE DIGIT START BETWEEN 7 TO 9 THEN ADD 9 DIGIT BETWEEN 0 TO 9 IT PERMITS +919726174054 / 09726174054
        let MOBILE_REGEX = "^([+][9][1]|[9][1]|[0]){0,1}([7-9]{1})([0-9]{9})$"
        let mobileTest = NSPredicate(format: "SELF MATCHES %@", MOBILE_REGEX)
        let result =  mobileTest.evaluate(with: mobile)
        return result
    }
    
    func isValidPassword(pwd: String) -> Bool
    {
        //Minimum 6 Max 8 characters at least 1 Alphabet, 1 Number and 1 Special Character:
        let PASS_REGEX = "^(?=.*[A-Za-z])(?=.*\\d)(?=.*[$@$!%*#?&])[A-Za-z\\d$@$!%*#?&]{6,8}$"
        let passTest = NSPredicate(format: "SELF MATCHES %@", PASS_REGEX)
        let result =  passTest.evaluate(with: pwd)
        return result
    }
    func isValidCPassword(pwd: String,cpass:String) -> Bool
    {
        //Minimum 6 Max 8 characters at least 1 Alphabet, 1 Number and 1 Special Character:
        //let PASS_REGEX = "^(?=.*[A-Za-z])(?=.*\\d)(?=.*[$@$!%*#?&])[A-Za-z\\d$@$!%*#?&]{6,8}$"
        let PASS_REGEX = pwd
        let passTest = NSPredicate(format: "SELF MATCHES %@", PASS_REGEX)
        let result =  passTest.evaluate(with: cpass)
        return result
    }
}
