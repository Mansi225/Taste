//
//  Home.swift
//  TasteBuds
//
//  Created by MAC2 on 26/12/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit
import SkyFloatingLabelTextField

class Home: UIViewController {

    @IBOutlet weak var pass: SkyFloatingLabelTextFieldWithIcon!
    override func viewDidLoad() {
        super.viewDidLoad()
        //add()
        let nav = navigationController
        nav?.isNavigationBarHidden = false
        
    }
    /*func add()
    {
        pass.placeholder = "Pass"
        pass.selectedLineColor = UIColor.blue
        pass.selectedLineHeight = 1
        pass.selectedTitle = "password"
        pass.selectedTitleColor = UIColor.blue
        pass.isSecureTextEntry = true
        
        pass.iconType = .image
        pass.iconImage = UIImage(named: "showPass.png")
        
    }*/
}
