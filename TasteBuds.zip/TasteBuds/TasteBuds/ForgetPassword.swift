
import UIKit
import SkyFloatingLabelTextField
import TransitionButton

class ForgetPassword: UIViewController
{

    @IBOutlet weak var fgView: UIView!
    let cont = Controls()
    
    var send = TransitionButton()
    var email = SkyFloatingLabelTextField()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.fgView.layer.cornerRadius = 10
        fgView.layer.masksToBounds = false
        fgView.layer.shadowOffset = CGSize(width: 2, height: 2)
        fgView.layer.shadowOpacity = 0.9
        fgView.layer.opacity = 0.9
        
        addBtn()
        addTxt()
    }
    
    func addTxt()
    {
        email = cont.customtext(frame: CGRect(x: 53, y: 129, width: 237, height: 40), placeholder: "Email to reset the password", selLineCol: UIColor.blue, selLineHei: 2, selTitle: "Email Here", selTitleCol: UIColor.blue, secure: false)
        self.fgView.addSubview(email)
    }
    
    func addBtn()
    {
        send = TransitionButton(frame: CGRect(x: 115, y: 219, width: 150, height: 30))
        send.backgroundColor = UIColor.lightGray
        send.setTitle("SEND LINK", for: .normal)
        send.cornerRadius = 20
        send.spinnerColor = UIColor.white
        send.addTarget(self, action: #selector(self.btnSend), for: .touchUpInside)
        self.fgView.addSubview(send)
    }
    
    @objc func btnSend()
    {
        send.startAnimation()
        let qualityOfServiceClass = DispatchQoS.QoSClass.background
        let backgroundQueue = DispatchQueue.global(qos: qualityOfServiceClass)
        backgroundQueue.async(execute: {
            
            sleep(3)
            DispatchQueue.main.async(execute: { () -> Void in
                self.send.stopAnimation(animationStyle: .expand, completion: {
                                    })
            })
        })
    }
}

